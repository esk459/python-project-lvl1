def welcome_user():
    print('May I have your name? ', end='')
    name = input()
    print('Hello,', name, "!")
